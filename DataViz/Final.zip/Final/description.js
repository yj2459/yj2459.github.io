var table_post, table_pre;
var griefData;
var preDeterminants = [];
var postDeterminants = [];
var griefvalues;


var post = {
"Anger" : [250, 130],
"Crying" : [250, 160],
"Dwelling on events leading up to the death" : [250, 190],
"Feeling of numbness" : [250, 250],
"Feeling that life had little or no meaning" : [250, 280],
"Feeling the presence of dead person" : [250, 310],
"Frustration" : [250, 340],
"Guilt" : [250, 370],
"Inability to control emotions in private" : [250, 400],
"Inability to control emotions in public" : [250, 430],
"Lack of concentration" : [250, 460],
"Loss of appetitle" : [250, 490],
"Loss of interest" : [250, 520],
"Loss of sleep" : [250, 550],
"Oversleep" : [250, 580],
"Thinking at times the dead person was still alive" : [250, 610]
};

// var pre = {
// "Are you atheist?",
// "Are you male?",
// "Have you educated less than 12 years?",
// "Have you worked for less than 7 years?",
// "Is the deceased less than 46 years old?",
// "Is the deceased not an adult child?",
// "Is the deceased your spouse?",
// "Is this your first time to lose someone?",
// "Was it suddenly happened without forewarning?",
// };

var subscales = {
"Physiological" : [500, 230],
"Behavioral" : [500, 310],
"Cognitive" : [500, 390],
"Attitudes toward Deceased" : [500, 470],
"Affective" : [500, 550],
};


function preload(){
	table_post = loadTable('post_grief.csv', 'csv', 'header');
  table_pre = loadTable('pre_grief.csv', 'csv', 'header');
}

function setup() {
  createCanvas(1800, 800);

  loadData();

}

function draw() {
	background(255);

	//title
	textSize(38);
  text("Grief Duration Correlated Factors", 0, 50);

 	var margin = 10;

 	//console.log(post[1]);
 	console.log(post);

	// //Post Determinants
 //  for (var i = 0; i < post.length; i++) {
 //  	var x_post = 250;
 //  	var y_post = (100 + 30*i);
 //  	ellipse(x_post, y_post, 5, 5);
 //  	textSize(10);
 //  	text(post[i], margin, 3 + y_post);
 //  }
  
 //  //Subscales
 //  for (var j = 0; j < subscales.length; j++) {
 //  	var x_subscales = 500;
 //  	var y_subscales = (150 + 80*j);
 //  	ellipse(500, 150 + 80*j, 5, 5);
 //  	textSize(10);
 //  	text(subscales[j], margin + 510, 153 + 80*j);
 //  }

  //draw lines
  for (var i = 0; i < 81; i++) {
  	var startXY_01 = post[postDeterminants[0].get(0)];
  	var endXY_01 = subscales[postDeterminants[0].get(1)];
  	
  	strokeWeight(1)
  	ellipse(startXY_01[0], startXY_01[1], 5, 5);
  	ellipse(endXY_01[0], endXY_01[1], 5, 5);
  	
  	strokeWeight(map(postDeterminants[0].get(2), 0, 1, 0, 10));
  	line(startXY_01[0], startXY_01[1], endXY_01[0], endXY_01[1]);


  	//
  	var startXY_02 = post[postDeterminants[1].get(0)];
  	var endXY_02 = subscales[postDeterminants[1].get(1)];
  	
  	strokeWeight(1)
  	ellipse(startXY_02[0], startXY_02[1], 5, 5);
  	ellipse(endXY_02[0], endXY_02[1], 5, 5);
  	
  	strokeWeight(map(postDeterminants[1].get(2), 0, 1, 0, 10));
  	line(startXY_02[0], startXY_02[1], endXY_02[0], endXY_02[1]);



  }

}










function loadData() {
	for (var i = 0; i < 81; i++) {
		var post_factors= table_post.getRow(i);
		// var pre_factors = table_pre.getRow(i);

		append(postDeterminants, post_factors);
		// append(preDeterminants, pre_factors);

		//console.log(postDeterminants[i].get(1));
		//console.log(i);
	}

}


function mousePressed() {
  console.log("mousePressed function");
}